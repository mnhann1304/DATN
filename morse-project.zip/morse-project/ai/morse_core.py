"""Thư viện Morse lõi + hàm CER.

Quy ước chuỗi Morse (cả nhóm dùng chung, ghi trong docs/data_spec.md):
  - chấm = '.', gạch = '-'
  - 1 khoảng trắng ' ' giữa hai ký tự
  - ' / ' (khoảng trắng, gạch chéo, khoảng trắng) giữa hai từ
"""
from __future__ import annotations

MORSE = {
    "A": ".-", "B": "-...", "C": "-.-.", "D": "-..", "E": ".", "F": "..-.",
    "G": "--.", "H": "....", "I": "..", "J": ".---", "K": "-.-", "L": ".-..",
    "M": "--", "N": "-.", "O": "---", "P": ".--.", "Q": "--.-", "R": ".-.",
    "S": "...", "T": "-", "U": "..-", "V": "...-", "W": ".--", "X": "-..-",
    "Y": "-.--", "Z": "--..",
    "0": "-----", "1": ".----", "2": "..---", "3": "...--", "4": "....-",
    "5": ".....", "6": "-....", "7": "--...", "8": "---..", "9": "----.",
    ".": ".-.-.-", ",": "--..--", "?": "..--..", "!": "-.-.--",
    "'": ".----.", "/": "-..-.", "-": "-....-", ":": "---...",
}
INVERSE = {v: k for k, v in MORSE.items()}
WORD_SEP = "/"


def text_to_morse(text: str, strict: bool = True) -> str:
    """Văn bản -> chuỗi Morse. strict=True: ký tự lạ gây ValueError, False: bỏ qua."""
    words = text.upper().split()
    out_words = []
    for word in words:
        codes = []
        for ch in word:
            if ch in MORSE:
                codes.append(MORSE[ch])
            elif strict:
                raise ValueError(f"Ký tự không có trong bảng Morse: {ch!r}")
        if codes:
            out_words.append(" ".join(codes))
    return f" {WORD_SEP} ".join(out_words)


def morse_to_text(morse: str, unknown: str = "?") -> str:
    """Chuỗi Morse -> văn bản. Mã không hợp lệ được thay bằng `unknown`."""
    words = []
    for word in morse.strip().split(WORD_SEP):
        letters = [INVERSE.get(code, unknown) for code in word.split()]
        if letters:
            words.append("".join(letters))
    return " ".join(words)


def edit_ops(ref: str, hyp: str) -> int:
    """Số phép chèn/xóa/thay tối thiểu để biến ref thành hyp (Levenshtein)."""
    if ref == hyp:
        return 0
    prev = list(range(len(hyp) + 1))
    for i, rc in enumerate(ref, start=1):
        cur = [i]
        for j, hc in enumerate(hyp, start=1):
            cost = 0 if rc == hc else 1
            cur.append(min(prev[j] + 1,        # xóa
                           cur[j - 1] + 1,     # chèn
                           prev[j - 1] + cost))  # thay
        prev = cur
    return prev[-1]


def cer(ref: str, hyp: str) -> float:
    """CER (%) = số phép chỉnh sửa / số ký tự gốc * 100, tính cả khoảng trắng.
    Nếu hyp rỗng, mọi ký tự gốc là lỗi xóa (CER = 100)."""
    if not ref:
        raise ValueError("Văn bản gốc rỗng, không tính được CER")
    return edit_ops(ref, hyp) / len(ref) * 100.0


def cer_total(pairs: list[tuple[str, str]]) -> float:
    """CER gộp nhiều bản thu (như đề cương): tổng lỗi / tổng ký tự gốc * 100."""
    total_ref = sum(len(r) for r, _ in pairs)
    if total_ref == 0:
        raise ValueError("Không có ký tự gốc nào")
    return sum(edit_ops(r, h) for r, h in pairs) / total_ref * 100.0
