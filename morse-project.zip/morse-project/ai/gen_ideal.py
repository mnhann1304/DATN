"""Ngày 4 – Bộ sinh ON/OFF chuẩn (nhịp lý tưởng theo ITU-R M.1677-1).

Đơn vị chấm T = 1200 / WPM (ms).
Chấm 1T, gạch 3T; nghỉ trong ký tự 1T, giữa ký tự 3T, giữa từ 7T.
"""
from __future__ import annotations
from morse_core import text_to_morse

DOT, DASH = "dot", "dash"
GAP_INTRA, GAP_CHAR, GAP_WORD = "gap_intra", "gap_char", "gap_word"
UNITS = {DOT: 1, DASH: 3, GAP_INTRA: 1, GAP_CHAR: 3, GAP_WORD: 7}
STATE = {DOT: "ON", DASH: "ON", GAP_INTRA: "OFF", GAP_CHAR: "OFF", GAP_WORD: "OFF"}
CLASSES = [DOT, DASH, GAP_INTRA, GAP_CHAR, GAP_WORD]   # 5 lớp cho mô hình (Ngày 18)


def unit_ms(wpm: float) -> float:
    """Độ dài một chấm (ms) ở tốc độ `wpm`."""
    return 1200.0 / wpm


def pattern(text: str) -> list[str]:
    """Văn bản -> danh sách nhãn đoạn luân phiên ON/OFF (dot, gap_intra, dash, ...)."""
    labels: list[str] = []
    for wi, word in enumerate(text_to_morse(text).split(" / ")):
        if wi:
            labels.append(GAP_WORD)
        for ci, code in enumerate(word.split()):
            if ci:
                labels.append(GAP_CHAR)
            for si, sym in enumerate(code):
                if si:
                    labels.append(GAP_INTRA)
                labels.append(DOT if sym == "." else DASH)
    return labels


def total_units(text: str) -> int:
    """Tổng số đơn vị T của thông điệp (không tính khoảng nghỉ cuối)."""
    return sum(UNITS[lab] for lab in pattern(text))


def ideal_segments(text: str, wpm: float) -> list[dict]:
    """Danh sách đoạn {state, start_ms, dur_ms} đúng theo docs/data_spec.md."""
    T = unit_ms(wpm)
    segs, t = [], 0
    for lab in pattern(text):
        d = round(UNITS[lab] * T)
        segs.append({"state": STATE[lab], "start_ms": t, "dur_ms": d})
        t += d
    return segs
