import json, os, subprocess, sys

ROOT = os.path.join(os.path.dirname(__file__), "..")


def test_split_human_session(tmp_path, monkeypatch):
    sess = {"format": "typing_session_v1", "operator": "N01", "device": "test",
            "takes": [{"n": 1, "message": "SOS", "operator": "N01", "device": "test",
                       "recorded_at": "2026-11-24T02:00:00Z",
                       "segments": [{"state": "ON", "start_ms": 0, "dur_ms": 100},
                                    {"state": "OFF", "start_ms": 100, "dur_ms": 100},
                                    {"state": "ON", "start_ms": 200, "dur_ms": 300}]},
                      {"n": 2, "message": "BAD", "operator": "N01", "device": "test",
                       "recorded_at": "2026-11-24T02:01:00Z", "segments": []}]}
    p = tmp_path / "H_N01_20261124-0900_session.json"
    p.write_text(json.dumps(sess))
    sys.path.insert(0, os.path.join(ROOT, "tools"))
    import split_human_session as sp
    monkeypatch.setattr(sp, "OUT", str(tmp_path / "out"))
    sp.split(str(p))
    files = sorted(os.listdir(tmp_path / "out"))
    assert files == ["H_N01_20261124-0900_001_meta.json", "H_N01_20261124-0900_001_segments.json"]
