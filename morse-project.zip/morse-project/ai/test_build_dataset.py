import json, os
from build_dataset import build, check_no_leak, load_lines, HERE
from test_gen_noisy import check_structure


def test_build_small_and_no_leak(tmp_path):
    meta = build(str(tmp_path), n_total=300, seed=1)
    assert sum(meta["counts"].values()) + meta["skipped_empty"] == 300
    assert meta["counts"]["train"] > meta["counts"]["val"]
    assert check_no_leak(str(tmp_path)) == []
    with open(tmp_path / "train.jsonl", encoding="utf-8") as f:
        first = json.loads(f.readline())
    check_structure(first["segments"])
    assert first["split"] == "train" and 0 <= first["operator"] < 20


def test_leak_checker_detects_problem(tmp_path):
    build(str(tmp_path), n_total=100, seed=2)
    with open(tmp_path / "train.jsonl", encoding="utf-8") as f:
        row = json.loads(f.readline())
    row["id"] = "X"
    with open(tmp_path / "test.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(row) + "\n")
    assert check_no_leak(str(tmp_path)) != []


def test_reproducible(tmp_path):
    build(str(tmp_path / "a"), n_total=50, seed=3)
    build(str(tmp_path / "b"), n_total=50, seed=3)
    assert (tmp_path / "a" / "train.jsonl").read_text() == (tmp_path / "b" / "train.jsonl").read_text()


def test_wordlist_valid_morse_chars():
    from morse_core import MORSE
    for w in load_lines(os.path.join(HERE, "wordlist_en.txt")):
        assert all(c in MORSE for c in w)
