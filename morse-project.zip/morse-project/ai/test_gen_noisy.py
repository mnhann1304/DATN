import numpy as np
import pytest
from gen_ideal import ideal_segments
from gen_noisy import (generate, sample_operator, word_wpms, Errors, Operator, LEVELS)


def check_structure(segs):
    assert segs, "rỗng"
    assert segs[0]["state"] == "ON" and segs[-1]["state"] == "ON"
    assert segs[0]["start_ms"] == 0
    for s in segs:
        assert isinstance(s["dur_ms"], int) and s["dur_ms"] >= 1
    for a, b in zip(segs, segs[1:]):
        assert b["start_ms"] == a["start_ms"] + a["dur_ms"]
        assert a["state"] != b["state"]


@pytest.mark.parametrize("wpm", [6, 8, 10, 15, 20])
def test_clean_equals_ideal(wpm):
    r = generate("HELLO WORLD", wpm, level="clean", seed=1)
    assert r["segments"] == ideal_segments("HELLO WORLD", wpm)


def test_deterministic_by_seed():
    a = generate("SOS SEND HELP", 10, level="medium", seed=5)
    b = generate("SOS SEND HELP", 10, level="medium", seed=5)
    c = generate("SOS SEND HELP", 10, level="medium", seed=6)
    assert a == b and a != c


@pytest.mark.parametrize("level", list(LEVELS))
def test_structure_valid_many_seeds(level):
    for seed in range(200):
        r = generate("MORSE CODE FPGA", 10, level=level, operator=sample_operator(seed % 7), seed=seed)
        if r["segments"]:
            check_structure(r["segments"])
            assert len(r["labels"]) == len(r["segments"])


def test_word_wpms_three_chunks():
    assert word_wpms("A B C", (6, 10, 6)) == [6, 10, 6]
    assert word_wpms("A B", 8) == [8, 8]


def test_speed_change_between_words():
    r = generate("E E E", (6, 10, 6), level="clean")
    assert [s["dur_ms"] for s in r["segments"] if s["state"] == "ON"] == [200, 120, 200]


def test_jitter_statistics():
    # chỉ có jitter: dot trung bình ~ T, gạch/chấm ~ dash_ratio của người gõ
    op = Operator(dash_ratio=2.5)
    r = generate("ET " * 300, 10, level="medium", operator=op, seed=3,
                 jitter=0.2, drift=0.0, errors=Errors())
    dots = [s["dur_ms"] for s, l in zip(r["segments"], r["labels"]) if l == "dot"]
    dashes = [s["dur_ms"] for s, l in zip(r["segments"], r["labels"]) if l == "dash"]
    assert np.mean(dots) == pytest.approx(120, rel=0.1)
    assert np.mean(dashes) / np.mean(dots) == pytest.approx(2.5, rel=0.1)


def test_quantize_to_frames():
    r = generate("HELLO", 10, level="clean", errors=Errors(quantize_ms=1000 / 30), seed=0)
    check_structure(r["segments"])
    edges = [0]
    for s in r["segments"]:
        edges.append(s["start_ms"] + s["dur_ms"])
    frame = 1000 / 30
    assert all(abs(e / frame - round(e / frame)) < 0.05 for e in edges)


def test_operator_stable():
    assert sample_operator(3) == sample_operator(3)
    assert sample_operator(3) != sample_operator(4)
