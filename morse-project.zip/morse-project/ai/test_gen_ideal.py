import pytest
from gen_ideal import (pattern, total_units, ideal_segments, unit_ms, STATE)


@pytest.mark.parametrize("wpm,ms", [(6, 200), (8, 150), (10, 120), (15, 80), (20, 60)])
def test_unit_ms_matches_proposal(wpm, ms):
    assert unit_ms(wpm) == ms


def test_paris_is_standard_word():
    # Từ chuẩn PARIS dài 50 đơn vị gồm cả 7T nghỉ cuối từ; không tính nghỉ cuối là 43.
    assert total_units("PARIS") == 43
    assert total_units("PARIS PARIS") == 43 + 7 + 43


def test_pattern_sos():
    assert pattern("SOS") == ["dot", "gap_intra", "dot", "gap_intra", "dot", "gap_char",
                              "dash", "gap_intra", "dash", "gap_intra", "dash", "gap_char",
                              "dot", "gap_intra", "dot", "gap_intra", "dot"]


def test_segments_structure():
    segs = ideal_segments("HELLO WORLD", 10)
    assert segs[0]["state"] == "ON" and segs[-1]["state"] == "ON"
    assert segs[0]["start_ms"] == 0
    for a, b in zip(segs, segs[1:]):
        assert b["start_ms"] == a["start_ms"] + a["dur_ms"]
        assert a["state"] != b["state"]


def test_segments_durations_10wpm():
    segs = ideal_segments("E T", 10)     # chấm, nghỉ giữa từ 7T, gạch
    assert [s["dur_ms"] for s in segs] == [120, 840, 360]
    assert [s["state"] for s in segs] == ["ON", "OFF", "ON"]


def test_empty_text():
    assert ideal_segments("", 10) == []
