import pytest
from morse_core import (text_to_morse, morse_to_text, edit_ops, cer, cer_total)


def test_sos():
    assert text_to_morse("SOS") == "... --- ..."


def test_word_separator():
    assert text_to_morse("HI YOU") == ".... .. / -.-- --- ..-"


def test_roundtrip():
    for msg in ["HELLO WORLD", "SOS SEND HELP", "MORSE CODE FPGA", "TEST 123"]:
        assert morse_to_text(text_to_morse(msg)) == msg


def test_lowercase_and_extra_spaces():
    assert text_to_morse("  hello   world ") == text_to_morse("HELLO WORLD")


def test_unknown_char():
    with pytest.raises(ValueError):
        text_to_morse("A#B")
    assert text_to_morse("A#B", strict=False) == ".- -..."


def test_invalid_code_becomes_question_mark():
    assert morse_to_text(".- ......... -...") == "A?B"


def test_edit_ops_basic():
    assert edit_ops("KITTEN", "SITTING") == 3
    assert edit_ops("", "ABC") == 3
    assert edit_ops("ABC", "") == 3
    assert edit_ops("ABC", "ABC") == 0


def test_cer_example_from_proposal():
    # "HE L LO" có 2 lỗi chèn so với "HELLO" -> 2/5 = 40%
    assert cer("HELLO", "HE L LO") == pytest.approx(40.0)


def test_cer_empty_output_is_all_deletions():
    assert cer("HELLO", "") == pytest.approx(100.0)


def test_cer_perfect():
    assert cer("SOS SEND HELP", "SOS SEND HELP") == 0.0


def test_cer_counts_spaces():
    assert cer("A B", "AB") == pytest.approx(100 / 3)


def test_cer_total_pools_recordings():
    pairs = [("HELLO", "HELLO"), ("HELLO", "HE L LO"), ("HELLO", "")]
    # lỗi: 0 + 2 + 5 = 7 ; ký tự gốc: 15
    assert cer_total(pairs) == pytest.approx(7 / 15 * 100)


def test_cer_empty_reference_raises():
    with pytest.raises(ValueError):
        cer("", "A")
