"""Kiểm tra file mẫu và các schema khớp nhau."""
import json, os
import jsonschema

ROOT = os.path.join(os.path.dirname(__file__), "..")

def load(*p):
    with open(os.path.join(ROOT, *p), encoding="utf-8") as f:
        return json.load(f)

def test_sample_segments_match_schema():
    jsonschema.validate(load("data", "samples", "example_SOS_10wpm_segments.json"),
                        load("docs", "segments.schema.json"))

def test_sample_segments_are_contiguous():
    segs = load("data", "samples", "example_SOS_10wpm_segments.json")
    for a, b in zip(segs, segs[1:]):
        assert b["start_ms"] == a["start_ms"] + a["dur_ms"]
        assert a["state"] != b["state"]

def test_sample_message_matches_schema():
    msg = {"sender": "B", "receiver": "A", "channel": "audio",
           "morse_raw": "... --- ...", "text_raw": "SOS", "text_corrected": "SOS",
           "method": "web_auto", "sent_at": "2026-11-23T08:30:00Z"}
    jsonschema.validate(msg, load("docs", "message.schema.json"))
