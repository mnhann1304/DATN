"""Ngày 6 – Sinh bộ dữ liệu giả lập quy mô lớn, chia train/val/test.

Chạy:  python build_dataset.py --out ../data/synthetic --n 5000
Chống rò rỉ: (1) mỗi văn bản chỉ nằm ở một tập, (2) mỗi người gõ (operator) chỉ nằm ở
một tập, (3) không văn bản nào chứa thông điệp thử trong docs/test_messages.txt.
"""
from __future__ import annotations
import argparse, json, os
import numpy as np

from gen_noisy import generate, sample_operator
from morse_core import text_to_morse

HERE = os.path.dirname(os.path.abspath(__file__))
WPMS = [6, 8, 10, 15, 20]
LEVEL_P = {"clean": 0.10, "light": 0.30, "medium": 0.40, "heavy": 0.20}
MULTI_SPEED_P = 0.15          # xác suất mẫu đổi tốc độ 6 -> 10 -> 6
SPLIT_FRAC = {"train": 0.8, "val": 0.1, "test": 0.1}
OPERATORS = {"train": list(range(0, 20)), "val": list(range(20, 25)), "test": list(range(25, 30))}


def load_lines(path):
    with open(path, encoding="utf-8") as f:
        return [ln.strip().upper() for ln in f if ln.strip() and not ln.startswith("#")]


def make_texts(n, rng, words, reserved):
    texts, seen = [], set()
    letters = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
    guard = 0
    while len(texts) < n and guard < n * 50:
        guard += 1
        if rng.random() < 0.75:
            k = int(rng.integers(2, 6))
            t = " ".join(rng.choice(words, size=k))
        else:
            groups = ["".join(rng.choice(letters, size=int(rng.integers(2, 6))))
                      for _ in range(int(rng.integers(2, 5)))]
            t = " ".join(groups)
        if len(t) > 32 or t in seen or any(r in t for r in reserved):
            continue
        seen.add(t)
        texts.append(t)
    if len(texts) < n:
        raise RuntimeError("Không đủ văn bản khác nhau, hãy mở rộng danh sách từ")
    return texts


def build(out_dir, n_total=5000, seed=0, reserved_path=None, words_path=None):
    reserved_path = reserved_path or os.path.join(HERE, "..", "docs", "test_messages.txt")
    words_path = words_path or os.path.join(HERE, "wordlist_en.txt")
    reserved, words = load_lines(reserved_path), load_lines(words_path)
    rng = np.random.default_rng(seed)
    texts = make_texts(n_total, rng, words, reserved)
    n_train = int(n_total * SPLIT_FRAC["train"])
    n_val = int(n_total * SPLIT_FRAC["val"])
    parts = {"train": texts[:n_train], "val": texts[n_train:n_train + n_val],
             "test": texts[n_train + n_val:]}
    levels, lp = list(LEVEL_P), list(LEVEL_P.values())
    os.makedirs(out_dir, exist_ok=True)
    counts, skipped, idx = {}, 0, 0
    for split, tlist in parts.items():
        with open(os.path.join(out_dir, f"{split}.jsonl"), "w", encoding="utf-8") as f:
            counts[split] = 0
            for text in tlist:
                idx += 1
                op_id = int(rng.choice(OPERATORS[split]))
                wpm = (6, 10, 6) if rng.random() < MULTI_SPEED_P else int(rng.choice(WPMS))
                level = str(rng.choice(levels, p=lp))
                s = seed * 1_000_003 + idx
                r = generate(text, wpm, level=level, operator=sample_operator(op_id), seed=s)
                if not any(x["state"] == "ON" for x in r["segments"]):
                    skipped += 1
                    continue
                r.update({"id": f"S{idx:06d}", "split": split, "operator": op_id})
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
                counts[split] += 1
    meta = {"version": "1.0", "seed": seed, "n_requested": n_total, "counts": counts,
            "skipped_empty": skipped, "reserved_messages": reserved,
            "operators": OPERATORS, "level_probabilities": LEVEL_P,
            "wpms": WPMS, "multi_speed_probability": MULTI_SPEED_P}
    with open(os.path.join(out_dir, "meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=1, ensure_ascii=False)
    return meta


def check_no_leak(out_dir, reserved_path=None):
    """Trả về danh sách lỗi (rỗng = sạch)."""
    reserved_path = reserved_path or os.path.join(HERE, "..", "docs", "test_messages.txt")
    reserved = load_lines(reserved_path)
    texts, ops, errors = {}, {}, []
    for split in ("train", "val", "test"):
        texts[split], ops[split] = set(), set()
        with open(os.path.join(out_dir, f"{split}.jsonl"), encoding="utf-8") as f:
            for line in f:
                r = json.loads(line)
                texts[split].add(r["text"])
                ops[split].add(r["operator"])
                if any(m in r["text"] for m in reserved):
                    errors.append(f"{r['id']}: chứa thông điệp thử")
    for a, b in (("train", "val"), ("train", "test"), ("val", "test")):
        if texts[a] & texts[b]:
            errors.append(f"văn bản trùng giữa {a} và {b}: {len(texts[a] & texts[b])}")
        if ops[a] & ops[b]:
            errors.append(f"người gõ trùng giữa {a} và {b}: {sorted(ops[a] & ops[b])}")
    return errors


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(HERE, "..", "data", "synthetic"))
    ap.add_argument("--n", type=int, default=5000)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()
    m = build(a.out, a.n, a.seed)
    print("Đã tạo:", m["counts"], "bỏ qua:", m["skipped_empty"])
    errs = check_no_leak(a.out)
    print("Kiểm tra rò rỉ:", "SẠCH" if not errs else errs)
    raise SystemExit(1 if errs else 0)
