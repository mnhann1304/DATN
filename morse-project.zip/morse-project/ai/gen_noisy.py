"""Ngày 5 – Mô hình sai lệch người gõ và lỗi tín hiệu.

Từ nhịp lý tưởng, thêm:
  1) Thói quen của từng người gõ (tỷ lệ gạch/chấm, độ dài các khoảng nghỉ).
  2) Jitter ngẫu nhiên từng đoạn và tốc độ trôi dần.
  3) Đổi tốc độ giữa chừng (ví dụ 6 -> 10 -> 6 WPM, đổi ở ranh giới từ).
  4) Lỗi thu: xung nhiễu, ON bị tách đôi, hai ON dính nhau, mất chấm,
     lệch cạnh, lượng tử hóa theo khung hình (camera).
Mọi thứ cố định theo `seed` để tái tạo được.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np

from gen_ideal import (pattern, UNITS, STATE, unit_ms,
                       DOT, DASH, GAP_INTRA, GAP_CHAR, GAP_WORD)
from morse_core import text_to_morse


@dataclass
class Operator:
    """Thói quen một người gõ: bội số của T cho từng loại đoạn."""
    dash_ratio: float = 3.0
    gap_intra: float = 1.0
    gap_char: float = 3.0
    gap_word: float = 7.0


def sample_operator(op_id: int) -> Operator:
    """Hồ sơ người gõ ổn định theo op_id (cùng id luôn ra cùng thói quen)."""
    rng = np.random.default_rng(10_000 + op_id)
    return Operator(
        dash_ratio=float(np.clip(rng.normal(3.0, 0.4), 2.0, 4.2)),
        gap_intra=float(np.clip(rng.normal(1.0, 0.2), 0.6, 1.6)),
        gap_char=float(np.clip(rng.normal(3.0, 0.7), 1.6, 5.0)),
        gap_word=float(np.clip(rng.normal(7.0, 1.5), 4.0, 11.0)),
    )


@dataclass
class Errors:
    p_spur: float = 0.0        # mỗi đoạn nghỉ: chèn xung nhiễu ngắn
    p_split: float = 0.0       # mỗi đoạn ON: bị tách đôi bởi khe OFF ngắn
    p_merge: float = 0.0       # mỗi nghỉ trong/giữa ký tự: biến mất (hai ON dính nhau)
    p_drop: float = 0.0        # mỗi chấm: bị mất
    edge_sigma_ms: float = 0.0  # lệch cạnh ngẫu nhiên (độ lệch chuẩn, ms)
    quantize_ms: float = 0.0    # lượng tử hóa cạnh theo khung (33.3 cho camera 30 fps); 0 = tắt


LEVELS = {
    "clean":  dict(jitter=0.00, drift=0.00, human=False, errors=Errors()),
    "light":  dict(jitter=0.10, drift=0.01, human=True,
                   errors=Errors(0.002, 0.002, 0.002, 0.002, 5.0)),
    "medium": dict(jitter=0.20, drift=0.02, human=True,
                   errors=Errors(0.010, 0.010, 0.010, 0.010, 10.0)),
    "heavy":  dict(jitter=0.30, drift=0.04, human=True,
                   errors=Errors(0.030, 0.030, 0.030, 0.030, 20.0)),
}


def word_wpms(text: str, wpm) -> list[float]:
    """Tốc độ cho từng từ. `wpm` là số, hoặc dãy (vd (6,10,6)) chia thông điệp thành
    các đoạn liên tiếp theo ranh giới từ."""
    words = text.split()
    if isinstance(wpm, (int, float)):
        return [float(wpm)] * len(words)
    seq, n, k = list(wpm), len(words), len(wpm)
    return [float(seq[min(i * k // n, k - 1)]) for i in range(n)]


def _build_items(text, wpm, op, jitter, drift, rng):
    ratio = {DOT: 1.0, DASH: op.dash_ratio, GAP_INTRA: op.gap_intra,
             GAP_CHAR: op.gap_char, GAP_WORD: op.gap_word}
    wp = word_wpms(text, wpm)
    items, f, T_last = [], 1.0, None
    for wi, word in enumerate(text.split()):
        T = unit_ms(wp[wi])
        labels = pattern(word)
        if wi:   # nghỉ giữa từ, dùng nhịp của từ trước
            labels = [GAP_WORD] + labels
        for lab in labels:
            Tb = T_last if lab == GAP_WORD else T
            if drift > 0:
                f = float(np.clip(f * np.exp(rng.normal(0, drift)), 0.6, 1.6))
            dur = Tb * f * ratio[lab]
            if jitter > 0:
                dur *= float(np.exp(rng.normal(0, jitter)))
            items.append({"state": STATE[lab], "label": lab, "dur": dur, "T": Tb})
        T_last = T
    return items


def _inject_errors(items, err, rng):
    out = []
    for it in items:
        lab, dur, T = it["label"], it["dur"], it["T"]
        if lab == DOT and rng.random() < err.p_drop:               # mất chấm
            out.append({**it, "state": "OFF", "label": "drop"})
        elif it["state"] == "ON" and dur > 1.5 * T and rng.random() < err.p_split:   # tách đôi
            gap = float(rng.uniform(0.15, 0.4)) * T
            half = (dur - gap) / 2
            out += [{**it, "dur": half}, {"state": "OFF", "label": "split", "dur": gap, "T": T},
                    {**it, "dur": half}]
        elif lab in (GAP_INTRA, GAP_CHAR) and rng.random() < err.p_merge:   # hai ON dính nhau
            out.append({**it, "state": "ON", "label": "merge"})
        elif it["state"] == "OFF" and lab in (GAP_INTRA, GAP_CHAR, GAP_WORD) \
                and dur > 2 * T and rng.random() < err.p_spur:      # xung nhiễu
            spur = float(rng.uniform(0.2, 0.45)) * T
            a = (dur - spur) * float(rng.uniform(0.3, 0.7))
            out += [{**it, "dur": a}, {"state": "ON", "label": "spur", "dur": spur, "T": T},
                    {**it, "dur": dur - spur - a}]
        else:
            out.append(it)
    return out


def _merge_same_state(items):
    out = []
    for it in items:
        if out and out[-1]["state"] == it["state"]:
            prev = out[-1]
            label = prev["label"] if prev["dur"] >= it["dur"] else it["label"]
            out[-1] = {**prev, "dur": prev["dur"] + it["dur"], "label": label}
        else:
            out.append(dict(it))
    return out


def _to_segments(items, err, rng):
    """Cạnh (thời điểm đổi trạng thái) -> thêm lệch cạnh, lượng tử hóa -> đoạn nguyên ms."""
    if not items:
        return [], []
    edges = np.cumsum([0.0] + [it["dur"] for it in items])
    if err.edge_sigma_ms > 0:
        edges[1:] += rng.normal(0, err.edge_sigma_ms, size=len(edges) - 1)
    if err.quantize_ms > 0:
        edges = np.round(edges / err.quantize_ms) * err.quantize_ms
    edges = np.maximum.accumulate(np.rint(edges)).astype(int)
    kept = []
    for it, a, b in zip(items, edges[:-1], edges[1:]):
        if b > a:
            kept.append({**it, "dur": int(b - a)})
    kept = _merge_same_state(kept)
    while kept and kept[0]["state"] == "OFF":
        kept.pop(0)
    while kept and kept[-1]["state"] == "OFF":
        kept.pop()
    segs, labels, t = [], [], 0
    for it in kept:
        d = max(1, int(round(it["dur"])))
        segs.append({"state": it["state"], "start_ms": t, "dur_ms": d})
        labels.append(it["label"])
        t += d
    return segs, labels


def generate(text: str, wpm=10, *, level: str = "medium", operator: Operator | None = None,
             seed: int = 0, jitter=None, drift=None, errors: Errors | None = None) -> dict:
    """Sinh một mẫu. Trả về dict: text, morse, wpm, level, seed, segments, labels.
    `labels` là nhãn nguồn của từng đoạn (dot/dash/gap_*; hoặc spur/split/merge/drop khi
    đã có lỗi chèn vào). Với đoạn bị lỗi cấu trúc, nhãn chỉ mang tính gần đúng."""
    cfg = LEVELS[level]
    jitter = cfg["jitter"] if jitter is None else jitter
    drift = cfg["drift"] if drift is None else drift
    errors = cfg["errors"] if errors is None else errors
    op = (operator or Operator()) if cfg["human"] else Operator()
    rng = np.random.default_rng(seed)
    norm = " ".join(text.upper().split())
    items = _build_items(norm, wpm, op, jitter, drift, rng)
    items = _merge_same_state(_inject_errors(items, errors, rng))
    segs, labels = _to_segments(items, errors, rng)
    return {"text": norm, "morse": text_to_morse(norm), "wpm": wpm if isinstance(wpm, (int, float)) else list(wpm),
            "level": level, "seed": seed, "segments": segs, "labels": labels}
