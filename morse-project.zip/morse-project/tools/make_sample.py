"""Sinh file mẫu data/samples/example_SOS_10wpm_segments.json (minh họa định dạng)."""
import json, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "ai"))
from gen_ideal import ideal_segments

if __name__ == "__main__":
    out = os.path.join(os.path.dirname(__file__), "..", "data", "samples", "example_SOS_10wpm_segments.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(ideal_segments("SOS", 10), f, indent=1)
    print("Đã ghi", out)
