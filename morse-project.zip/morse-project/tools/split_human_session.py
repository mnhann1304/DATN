"""Tách file phiên gõ từ web/typing_recorder.html thành file theo quy ước của docs/data_spec.md.

Chạy:  python split_human_session.py H_N01_20261124-0930_session.json [file khác ...]
Ghi vào data/human/:  H_<người>_<số câu>_segments.json  và  H_<người>_<số câu>_meta.json
"""
import json, os, sys
import jsonschema

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
OUT = os.path.join(ROOT, "data", "human")
with open(os.path.join(ROOT, "docs", "segments.schema.json"), encoding="utf-8") as f:
    SCHEMA = json.load(f)


def split(path):
    with open(path, encoding="utf-8") as f:
        sess = json.load(f)
    assert sess.get("format") == "typing_session_v1", "không phải file phiên gõ"
    os.makedirs(OUT, exist_ok=True)
    ok = bad = 0
    stamp = os.path.basename(path).split("_")[2] if os.path.basename(path).count("_") >= 3 else "x"
    for t in sess["takes"]:
        op = sess["operator"]
        name = f"H_{op}_{stamp}_{t['n']:03d}"
        try:
            jsonschema.validate(t["segments"], SCHEMA)
        except jsonschema.ValidationError as e:
            print("  Bỏ qua", name, "-", e.message[:60]); bad += 1; continue
        with open(os.path.join(OUT, name + "_segments.json"), "w", encoding="utf-8") as f:
            json.dump(t["segments"], f)
        meta = {"condition_id": "H", "take": t["n"], "channel": "typing", "message": t["message"],
                "wpm_target": None, "operator": op, "device": sess.get("device", ""),
                "recorded_at": t["recorded_at"], "session": stamp}
        with open(os.path.join(OUT, name + "_meta.json"), "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=1)
        ok += 1
    print(f"{os.path.basename(path)}: ghi {ok} câu, bỏ {bad}")


if __name__ == "__main__":
    for p in sys.argv[1:]:
        split(p)
