# Đặc tả dữ liệu – phiên bản v0.2 (nháp, chờ Quỳnh và Ngọc xác nhận)

Người soạn: Nhàn. Mọi thay đổi ghi vào mục "Lịch sử thay đổi" ở cuối file.

## 1. Quy ước chung
- Thời gian tính bằng **mili giây (ms)**, số nguyên, tính từ đầu bản thu (t = 0).
- Chuỗi Morse: chấm `.`, gạch `-`; **1 khoảng trắng** giữa hai ký tự; ` / ` giữa hai từ.
- Văn bản: chữ HOA, không dấu; ký tự hợp lệ theo `ai/morse_core.py`.
- Múi giờ lưu trữ: UTC (ISO 8601, ví dụ `2026-11-23T08:30:00Z`); hiển thị trên Web theo UTC+7.
- Đơn vị chấm: T = 1200 / WPM (ms). 6, 8, 10, 15, 20 WPM -> 200, 150, 120, 80, 60 ms.
- Nghỉ: trong ký tự 1T, giữa ký tự 3T, giữa từ 7T. Chấm 1T, gạch 3T.

## 2. Đoạn tín hiệu (segments) – Quỳnh xuất, Nhàn đọc
Mỗi bản thu là một file `*_segments.json`: một danh sách đoạn luân phiên ON/OFF.
```json
{"state": "ON", "start_ms": 0, "dur_ms": 120}
```
- `state`: `"ON"` (có bíp/sáng) hoặc `"OFF"` (nghỉ).
- Các đoạn nối tiếp nhau, không chồng lấn: `start_ms` của đoạn sau = `start_ms + dur_ms` của đoạn trước.
- Đoạn OFF ở đầu/cuối bản thu có thể bỏ qua; nếu có thì ghi bình thường.
- Schema: `docs/segments.schema.json`; file mẫu: `data/samples/example_SOS_10wpm_segments.json`.

## 3. Siêu dữ liệu bản thu – Quỳnh ghi, đi kèm mỗi bản thu
File `*_meta.json`:
| Trường | Kiểu | Ý nghĩa |
|---|---|---|
| `condition_id` | chuỗi | Mã điều kiện, ví dụ `A05`, `L02` |
| `take` | số nguyên | Số thứ tự bản thu 1, 2, 3 |
| `channel` | chuỗi | `audio` hoặc `light` |
| `message` | chuỗi | Văn bản gốc |
| `wpm_target` | số | Tốc độ mục tiêu (với đổi nhịp ghi `"6-10-6"`) |
| `sample_rate_hz` / `fps` | số | Tần số lấy mẫu âm thanh hoặc fps thực của camera |
| `snr_db` | số | (âm thanh) SNR đo được |
| `noise_ratio_pct` | số | (ánh sáng) tỷ lệ biên độ đèn nhiễu đo được |
| `samples_in` / `samples_lost` | số | Để tính tỷ lệ mất mẫu |
| `recorded_at` | chuỗi | Thời điểm thu, UTC |
| `device` / `operator` / `session` | chuỗi | Thiết bị, người thu, buổi thu |

## 4. Tin nhắn – lưu trong cơ sở dữ liệu (Nhàn làm chủ)
Schema: `docs/message.schema.json`.
| Trường | Ý nghĩa |
|---|---|
| `id` | Mã tin |
| `sender` / `receiver` | `A` hoặc `B` |
| `channel` | `audio` hoặc `light` |
| `morse_raw` | Chuỗi Morse nhận được (trước hiệu chỉnh) |
| `text_raw` | Văn bản giải mã thô (trước hiệu chỉnh) |
| `text_corrected` | Văn bản sau hiệu chỉnh AI (có thể bằng `text_raw`) |
| `method` | `button`, `web_auto`, `typing` |
| `sent_at` / `received_at` | Thời điểm gửi/nhận, UTC |

**Quan trọng:** bảng CER của đề tài chỉ tính trên `text_raw`.

## 5. Quy ước đặt tên file
`<condition_id>_<take>_<loại>.<đuôi>` ví dụ:
- `A05_2_audio.wav`, `A05_2_segments.json`, `A05_2_meta.json`
- Đầu ra bộ giải mã: `A05_2_out_fixed.txt`, `A05_2_out_adaptive.txt`, `A05_2_out_ml.txt`
- Dữ liệu người gõ: `H_<mã người>_<số câu>_segments.json`

## 5A. Dữ liệu người gõ trên Web (thêm ở v0.2)
Trang `web/typing_recorder.html` xuất **một file cho mỗi phiên gõ**: `H_<mã người>_<ngày-giờ>_session.json`
```json
{"format": "typing_session_v1", "operator": "N01", "device": "...",
 "takes": [{"n": 1, "message": "GOOD MORNING", "operator": "N01", "device": "...",
            "recorded_at": "2026-11-24T02:00:00.000Z", "segments": [ ... ]}]}
```
`tools/split_human_session.py` tách file này thành `H_<người>_<ngày-giờ>_<số câu>_segments.json` và `_meta.json`
(`channel` = `"typing"`, `condition_id` = `"H"`). Dữ liệu người gõ dùng để **huấn luyện/chỉnh mô hình**, không dùng làm bản thu kiểm thử chính thức.

## 5B. Dữ liệu giả lập (thêm ở v0.2)
`ai/build_dataset.py` tạo `data/synthetic/{train,val,test}.jsonl`, mỗi dòng: `id, split, operator, text, morse, wpm,
level, seed, segments, labels`. `labels` là nhãn nguồn từng đoạn (dot, dash, gap_intra, gap_char, gap_word; hoặc spur,
split, merge, drop với đoạn bị lỗi cấu trúc). Văn bản và người gõ không trùng giữa các tập; không văn bản nào chứa thông
điệp trong `docs/test_messages.txt`.

## 6. Câu hỏi còn mở (cần Quỳnh/Ngọc trả lời)
1. Quỳnh: xuất ON/OFF bằng ngưỡng cố định hay còn xuất cả đặc trưng theo khung?
2. Ngọc: FPGA nhận dữ liệu qua UART ở khung gói tin nào, tốc độ baud bao nhiêu?
3. Ngọc: FPGA đếm thời gian theo số mẫu hay theo thời điểm byte đến?

## Lịch sử thay đổi
- v0.1 – bản nháp đầu tiên.
- v0.2 – thêm định dạng dữ liệu người gõ (5A) và dữ liệu giả lập (5B); `channel` có thêm giá trị `typing`.
