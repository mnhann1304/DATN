# Hệ thống giải mã Morse âm thanh và ánh sáng trên FPGA có hỗ trợ học máy

Nhóm: Ngọc (FPGA/phần cứng), Quỳnh (thu nhận tín hiệu), Nhàn (AI, backend).

## Cài đặt (làm 1 lần)
```
git clone <địa chỉ repo>
cd morse-project
python -m venv .venv
# Windows:   .venv\Scripts\activate
# Mac/Linux: source .venv/bin/activate
pip install -r requirements.txt
python check_env.py
```

## Chạy kiểm thử
```
cd ai
python -m pytest -v
```

## Lệnh hay dùng (chạy trong thư mục `ai/`)
```
python -m pytest -q                                   # chạy toàn bộ test
python build_dataset.py --out ../data/synthetic --n 5000   # sinh dữ liệu giả lập + kiểm tra rò rỉ
python ../tools/split_human_session.py <file_session.json>  # tách dữ liệu người gõ
```
Trang ghi nhịp gõ: mở `web/typing_recorder.html` bằng Chrome (không cần cài gì).

## Cấu trúc thư mục
| Thư mục | Nội dung |
|---|---|
| `ai/` | Thư viện Morse, bộ giải mã, mô hình, hiệu chỉnh ngôn ngữ |
| `backend/` | FastAPI, cơ sở dữ liệu, WebSocket |
| `web/` | Giao diện, trang ghi nhịp gõ |
| `data/` | Dữ liệu (chỉ `data/samples` được đẩy lên Git; còn lại chia sẻ qua Drive) |
| `eval/` | Script đánh giá CER, độ trễ, mất mẫu |
| `docs/` | Đặc tả dữ liệu, schema, tài liệu thuật toán |
| `tools/` | Script tiện ích |

## Quy tắc làm việc nhóm
1. Mỗi người làm trong thư mục của mình; sửa file của người khác thì báo trước.
2. `git pull` trước khi bắt đầu, commit nhỏ và có mô tả rõ, `git push` cuối ngày.
3. Đổi định dạng dữ liệu = sửa `docs/data_spec.md` trước, rồi mới sửa code.
4. Dữ liệu thật và dữ liệu kiểm thử chính thức không đẩy lên Git.
