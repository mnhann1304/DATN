"""Kiểm tra môi trường: chạy `python check_env.py`."""
import importlib
import sys

PACKAGES = ["numpy", "scipy", "sklearn", "hmmlearn", "rapidfuzz",
            "fastapi", "uvicorn", "sqlalchemy", "pytest", "jsonschema"]

print(f"Python {sys.version.split()[0]}")
missing = []
for name in PACKAGES:
    try:
        mod = importlib.import_module(name)
        print(f"  OK   {name:12s} {getattr(mod, '__version__', '')}")
    except ImportError:
        print(f"  THIẾU {name}")
        missing.append(name)

if missing:
    print("\nChạy: pip install -r requirements.txt")
    sys.exit(1)
print("\nMôi trường đã sẵn sàng.")
